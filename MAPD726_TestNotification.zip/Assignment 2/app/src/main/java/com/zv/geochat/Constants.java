package com.zv.geochat;

public interface Constants {
    String KEY_USER_NAME ="user_name";
}
