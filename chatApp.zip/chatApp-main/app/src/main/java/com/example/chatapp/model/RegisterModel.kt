package com.example.chatapp.model

class RegisterModel (
    var username : String? = null,
    var email : String? = null,
    var userID : String? = null,
    var image : String? = null,
) : java.io.Serializable