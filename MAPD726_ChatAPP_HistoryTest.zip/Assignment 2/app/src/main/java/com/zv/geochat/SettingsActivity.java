package com.zv.geochat;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;

public class SettingsActivity extends PreferenceActivity implements SharedPreferences.OnSharedPreferenceChangeListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preferences);
        setContentView(R.layout.activity_settings);



        // Get the Chat Session Message Counter preference value
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String chatSessionMessageCounterPref = sharedPreferences.getString("chat_session_message_counter", "2");

        // Set the summary text of the preference to the selected value
        Preference chatSessionMessageCounterPreference = findPreference("chat_session_message_counter");
        chatSessionMessageCounterPreference.setSummary(chatSessionMessageCounterPref + " messages");

        // Set the listener for the preference change
        chatSessionMessageCounterPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                // Set the summary text to the new value
                preference.setSummary(newValue.toString() + " messages");
                return true;
            }
        });
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        if (key.equals("chat_session_message_counter")) {
            // Update the summary text of the preference to the new value
            Preference chatSessionMessageCounterPreference = findPreference(key);
            String newValue = sharedPreferences.getString(key, "2");
            chatSessionMessageCounterPreference.setSummary(newValue + " messages");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Register the shared preference change listener
        PreferenceManager.getDefaultSharedPreferences(this).registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Unregister the shared preference change listener
        PreferenceManager.getDefaultSharedPreferences(this).unregisterOnSharedPreferenceChangeListener(this);
    }
}
